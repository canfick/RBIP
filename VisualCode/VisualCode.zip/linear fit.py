import pandas as pd
import numpy as np
import plotly.graph_objs as go
from plotly.offline import plot

sol_df = pd.read_csv(r"C:\Users\USER\Desktop\Omri_Yarden\VisualCode\Soulitions_Summery_with_new_points.csv", encoding='Windows-1255')
cal_df = pd.read_csv(r"path_to_cal_csv_file.csv", encoding='Windows-1255')

sol_df

# Create the scatter plot
fig = go.Figure()
fig.add_trace(go.Scatter(x=1/sol_df['Conductivity [uS/cm]'], y=sol_df['Impedance [Ohm]'], mode='markers'))
fig.add_trace(go.Scatter(x=1/sol_df['Conductivity [uS/cm]'], y=sol_df['Impedance [Ohm]'], mode='lines'))

fig.add_trace(go.Scatter(x=1/cal_df['Conductivity [uS/cm]'], y=cal_df['Impedance [Ohm]'], mode='markers'))
fig.add_trace(go.Scatter(x=1/cal_df['Conductivity [uS/cm]'], y=cal_df['Impedance [Ohm]'], mode='lines'))


# Perform linear regression
x = 1/sol_df['Conductivity [uS/cm]']
y = sol_df['Impedance [Ohm]']
coeffs = np.polyfit(x, y, 1)  # Perform linear regression, returns the coefficients
line = np.poly1d(coeffs)  # Create a function based on the coefficients
x_range = np.linspace(x.min(), x.max(), 100)  # Generate x values for the line
y_range = line(x_range)  # Calculate corresponding y values

x_cal = 1/cal_df['Conductivity [uS/cm]']
y_cal = cal_df['Impedance [Ohm]']
coeffs_cal = np.polyfit(x_cal, y_cal, 1)
line_cal = np.poly1d(coeffs_cal)
x_range_cal = np.linspace(x_cal.min(), x_cal.max(), 100)
y_range_cal = line_cal(x_range_cal)
fig.add_trace(go.Scatter(x=x_range_cal, y=y_range_cal, mode='lines', name='Linear Fit (cal CSV)'))


# Add the regression line to the plot
fig.add_trace(go.Scatter(x=x_range, y=y_range, mode='lines', name='Linear Fit'))

# Update the layout and show the figure
fig.update_layout(title='Impedance vs 1/Conductivity [cm/uS]', xaxis_title='1/Conductivity [cm/uS]', yaxis_title='Impedance [Ohm]')
fig.show()

# Save the figures to HTML file
with open('plotly_figures.html', 'w') as f:
    f.write(fig.to_html(full_html=False, include_plotlyjs='cdn'))
